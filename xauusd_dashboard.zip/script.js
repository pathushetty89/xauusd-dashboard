<section id="fundamental" class="tab-content">
  <h2>📰 Fundamental Analysis</h2>
  <div id="economic-calendar"></div>
  <h3>🔺 Twitter/X Live Feed</h3>
  <div id="twitter-feed"></div>
  <h3>📈 Investing.com Economic News</h3>
  <div id="investing-news"></div>
  <h3>📖 TradingView News</h3>
  <div id="tradingview-news"></div>
  <h3>📰 Reuters Commodities</h3>
  <div id="reuters-news"></div>
</section>
